<?= $this->extend('web/index'); ?>
<?= $this->section('webutama'); ?>

<div class="row">
    <div class="col-12 animated bounceIn">
        <div class="card">
            <div class="card-header">
                <h3>Pengumuman</h3>
            </div>
            <div class="card-body">
                <div class="activities">
                    <?php foreach ($pengumuman as $data) : ?>
                        <div class="activity">
                            <div class="activity-icon bg-primary text-white shadow-primary">
                                <i class="fas fa-bullhorn"></i>
                            </div>
                            <div class="activity-detail">
                                <div class="mb-2">
                                    <span class="text-job text-primary"><?= $data['tgl'] ?></span>
                                    <span class="bullet"></span>
                                    <a class="text-job" href="#"><?= $data['created_by'] ?></a>

                                </div>
                                <h5><?= $data['judul'] ?></h5>
                                <p><?= $data['pengumuman'] ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>

                </div>
            </div>
        </div>

    </div>
</div>

<?= $this->endSection(); ?>