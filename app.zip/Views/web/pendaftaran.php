<?= $this->extend('web/index'); ?>
<?= $this->section('webutama'); ?>



<?php if (strtotime(date('Y-m-d H:i:s')) < strtotime($pendaftaran['ppdb_open'])) { ?>

    <center>
        <h3>PENDAFTARAN BELUM DIBUKA</h3>
    </center>
    <div class="clock" style="margin:2em;"></div>


    <script>
        <?php
        $datetime = strtotime($pendaftaran['ppdb_open']) - strtotime(date('Y-m-d H:i:s'));
        ?>
        var datetime = <?= $datetime ?>;
        var clock = $('.clock').FlipClock({
            clockFace: 'DailyCounter',
            autoStart: false,
            callbacks: {
                stop: function() {
                    location.reload();
                }
            }
        });

        clock.setTime(datetime);
        clock.setCountdown(true);
        clock.start();
    </script>

<?php } elseif ($kuota <= $count) { ?>
    <h3>PENDAFTARAN DITUTUP KUOTA TERPENUHI <?= $sisa; ?></h3>
<?php } elseif (strtotime(date('Y-m-d H:i:s')) > strtotime($pendaftaran['ppdb_close'])) { ?>
    <h3>PENDAFTARAN SUDAH DITUTUP</h3>
<?php } else { ?>

    <div class="row">
        <div class="col-md-8 animated bounceInLeft">
            <div class="card">
                <div class="card-header">
                    <h4>Form Pendaftaran (ISI DENGAN BENAR)</h4>
                </div>

                <form id="form-daftar" method="POST" action="<?= base_url() ?>/crud/save">
                    <?= csrf_field() ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="nik">NIK (lihat di Kartu Keluarga)</label>
                            <input type="number" id="nik" maxlength="16" minlength="16" class="form-control" name="nik" placeholder="NIK" autocomplete="off" required>
                        </div>
                        <div class="form-group">
                            <label for="nama_lengkap">NAMA LENGKAP*</label>
                            <input type="text" id="nama" class="form-control" name="nama_lengkap" placeholder="Nama Lengkap" autocomplete="off" style="text-transform: uppercase;" required>
                        </div>

                        <div class="form-group">
                            <label>Jenis Kelamin</label>
                            <select class='form-control' name='jenkel' required>
                                <option selected value=''>Pilih Jenis Kelamin</option>
                                <option value='L'>Laki-Laki</option>
                                <option value='P'>Perempuan</option>
                            </select>
                        </div>
                        <!-- <div class="form-group">
                            <label for="asal_sekolah">ASAL SEKOLAH SMP/MTS</label>
                            <input type="text" id="asal_sekolah" class="form-control" name="asal_sekolah" placeholder="Asal Sekolah" autocomplete="off" style="text-transform: uppercase;" required>

                        </div> -->

                        <div class="form-group">
                            <label>Jurusan</label>
                            <select class='form-control' name='jurusan' required>
                                <option value=''>Pilih Jurusan</option>";
                                <?php foreach ($jurusan as $j) : ?>
                                    <option value='$j[id_jurusan]'><?= $j['nama_jurusan'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="no_hp">NO HANDPHONE (diisi untuk info dan konfirmasi)</label>
                            <input type="number" id="nohp" class="form-control" name="no_hp" placeholder="No HP/Whatsapp" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="tempat_lahir">TEMPAT LAHIR</label>
                                <input type="text" id="tempat" class="form-control" name="tempat_lahir" style="text-transform: uppercase;" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="tgl_lahir">TANGGAL LAHIR</label>
                                <input type="date" id="tgllahir" class="form-control datepicker" name="tgl_lahir" required>
                            </div>

                        </div>
                        <!-- <div class="form-group">
                        <label for="inputPassword4">PASSWORD (Mohon Diingat!)</label>
                        <input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password" required>
                    </div>
                    <a href="#" onclick="document.getElementById('captcha').src = 'securimage/securimage_show.php?' + Math.random(); return false">Refresh Kode</a>

                    <img class="p-b-5" id="captcha" src="securimage/securimage_show.php" alt="CAPTCHA Image" style="height:70px" /><br>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input class="form-control" type="text" name="kodepengaman" placeholder="masukan kode" required>
                        </div>
                    </div> -->
                        <div class="form-group mb-0">
                            <p>* HARAP ISIKAN DATA DENGAN BENAR</p>
                            <!-- <p>* PASSWORD PIN AKAN DIGUNAKAN UNTUK LOGIN</p> -->

                        </div>
                    </div>
                    <div class="card-footer">
                        <button id='btnsimpan' type="submit" class="btn btn-lg btn-primary">KIRIM DATA</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-4 animated bounceInRight">
            <div class="card">
                <div class="card-header">
                    <h4>Info Lebih Lanjut</h4>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled user-details list-unstyled-border list-unstyled-noborder">
                        <?php foreach ($kontak as $key) : ?>
                            <li class="media">
                                <img alt="image" class="mr-3 rounded-circle" width="50" src="<?= base_url() ?>/assets/img/avatar/avatar-1.png">
                                <div class="media-body">
                                    <div class="media-title"><?= $key['nama_kontak'] ?></div>
                                    <div class="text-job text-muted"><a href="https://api.whatsapp.com/send?phone=+62<?= $key['no_kontak'] ?>&text=njkjjkj"> <?= $key['no_kontak'] ?></a></div>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <script>
        // $('#form-daftar').submit(function(e) {
        //     e.preventDefault();
        //     $.ajax({
        //         type: 'POST',
        //         url: '',
        //         data: $(this).serialize(),
        //         beforeSend: function() {
        //             $('#btnsimpan').prop('disabled', true);
        //         },
        //         success: function(data) {
        //             var json = $.parseJSON(data);
        //             $('#btnsimpan').prop('disabled', false);
        //             if (json.pesan == 'ok') {
        //                 iziToast.success({
        //                     title: 'Mantap!',
        //                     message: 'Data berhasil disimpan',
        //                     position: 'topRight'
        //                 });
        //                 setTimeout(function() {
        //                     $('#isi_load').load('konfirmasi.php?id=' + json.id + '&pass=' + json.pass + '&nama=' + json.nama);
        //                 }, 2000);

        //             } else {
        //                 iziToast.error({
        //                     title: 'Maaf!',
        //                     message: json.pesan,
        //                     position: 'topCenter'
        //                 });
        //                 document.getElementById('captcha').src = 'securimage/securimage_show.php?' + Math.random();

        //             }
        //             //$('#bodyreset').load(location.href + ' #bodyreset');
        //         }
        //     });
        //     return false;
        // });
        if (jQuery().daterangepicker) {
            if ($(".datepicker").length) {
                $('.datepicker').daterangepicker({
                    locale: {
                        format: 'YYYY-MM-DD'
                    },
                    singleDatePicker: true,
                });
            }
            if ($(".datetimepicker").length) {
                $('.datetimepicker').daterangepicker({
                    locale: {
                        format: 'YYYY-MM-DD hh:mm'
                    },
                    singleDatePicker: true,
                    timePicker: true,
                    timePicker24Hour: true,
                });
            }
            if ($(".daterange").length) {
                $('.daterange').daterangepicker({
                    locale: {
                        format: 'YYYY-MM-DD'
                    },
                    drops: 'down',
                    opens: 'right'
                });
            }
        }
        if (jQuery().select2) {
            $(".select2").select2();
        }
    </script>

<?php } ?>

<?= $this->endSection(); ?>