<?php

namespace App\Controllers;

use App\Models\PendaftarModel;
use App\Models\JurusanModel;
use App\Models\SettingModel;
use App\Models\KontakModel;
use App\Models\PengumumanModel;


class Web extends BaseController
{
    protected $pendaftarModel;
    protected $settingModel;
    protected $kontakModel;
    protected $jurusanModel;
    protected $pengumumanModel;
    public function __construct()
    {
        $this->pendaftarModel = new PendaftarModel();
        $this->settingModel = new SettingModel();
        $this->jurusanModel = new JurusanModel();
        $this->kontakModel = new KontakModel();
        $this->pengumumanModel = new PengumumanModel();
    }

    public function index()
    {
        $data['count'] = $this->pendaftarModel->countAll();
        $data['setting'] = $this->settingModel->find(1);
        $data['kuota'] = $this->jurusanModel->findAll();
        $data['syarat'] = $this->settingModel->find(1);
        $data['kontak'] = $this->kontakModel->findAll();
        $data['jurusan'] = $this->jurusanModel->findAll();
        $data['pendaftaran'] = $this->settingModel->find(1);
        $data['kontak'] = $this->kontakModel->findAll();
        $data['cuota'] = 0;
        // foreach ($this->jurusanModel->findAll() as $key) {
        //     $data['cuota'] = $data['cuota'] + $key['cuota'];
        // }
        return view('web/home', $data);
    }
    // public function home()
    // {

    //     $data['kuota'] = $this->jurusanModel->findAll();
    //     $data['syarat'] = $this->settingModel->find(1);
    //     $data['count'] = $this->pendaftarModel->countAll();
    //     $data['kontak'] = $this->kontakModel->findAll();
    //     return view('web/home', $data);
    // }
    public function pendaftaran()
    {
        $data['jurusan'] = $this->jurusanModel->findAll();
        $data['count'] = $this->pendaftarModel->countAll();
        $data['pendaftaran'] = $this->settingModel->find(1);
        $data['kontak'] = $this->kontakModel->findAll();
        $data['setting'] = $this->settingModel->find(1);
        $data['kuota'] = 0;
        foreach ($this->jurusanModel->findAll() as $key) {
            $data['kuota'] = $data['kuota'] + $key['kuota'];
        }
        return view('web/pendaftaran', $data);
    }
    public function pengumuman()
    {

        $data['setting'] = $this->settingModel->find(1);
        $data['pengumuman'] = $this->pengumumanModel->findAll();
        return view('web/pengumuman', $data);
    }
}
